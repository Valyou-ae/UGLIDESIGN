/**
 * Data exports
 */

export { COLORS, default as colors } from './colors';
export { SIZES, default as sizes } from './sizes';
export { PRODUCTS, default as products } from './products';
